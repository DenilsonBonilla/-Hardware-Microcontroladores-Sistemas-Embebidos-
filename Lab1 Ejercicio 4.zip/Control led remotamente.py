# Archivo: control_led_remotamente.py
import socket
import RPi.GPIO as GPIO

# Configuración de pines
led_pin = 18

GPIO.setmode(GPIO.BCM)
GPIO.setup(led_pin, GPIO.OUT)

# Dirección IP y puerto para escuchar comandos
host = ''
port = 12345

# Crear un socket TCP/IP
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind((host, port))
sock.listen(1)

def control_led(message):
    if message == "ON":
        GPIO.output(led_pin, GPIO.HIGH)
    elif message == "OFF":
        GPIO.output(led_pin, GPIO.LOW)

try:
    while True:
        # Esperar una conexión
        conn, addr = sock.accept()
        with conn:
            print('Conectado por', addr)
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                message = data.decode().strip()
                control_led(message)

except KeyboardInterrupt:
    GPIO.cleanup()
