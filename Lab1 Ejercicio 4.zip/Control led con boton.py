# Archivo: control_led_con_boton.py
import RPi.GPIO as GPIO
import time

# Configuración de pines
led_pin = 18
button_pin = 17

GPIO.setmode(GPIO.BCM)
GPIO.setup(led_pin, GPIO.OUT)
GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Función para controlar el LED
def control_led(channel):
    if GPIO.input(button_pin) == GPIO.LOW:
        GPIO.output(led_pin, GPIO.HIGH)
    else:
        GPIO.output(led_pin, GPIO.LOW)

# Configurar detección de eventos
GPIO.add_event_detect(button_pin, GPIO.BOTH, callback=control_led, bouncetime=300)

try:
    while True:
        time.sleep(0.1)

except KeyboardInterrupt:
    GPIO.cleanup()
